import pybullet as p
import pybullet_data
import numpy as np
import tensorflow as tf
import time

# Load the saved models
actor = tf.keras.models.load_model("actor_model_DDPG.h5")
print("Actor model loaded successfully!")

# Load PyBullet and initialize the robot
urdf_path = r"C:\Users\lilil\OneDrive\Documents\school\MSML642 Robotics\self_balancing_robot\urdf\robot4.urdf"
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
plane_id = p.loadURDF("plane.urdf")
p.setGravity(0, 0, -9.8)
robot_id = p.loadURDF(urdf_path, basePosition=[0, 0, 0.1])

# Disable velocity control for the wheel joints
right_wheel_joint = 1
left_wheel_joint = 2
p.setJointMotorControl2(robot_id, right_wheel_joint, controlMode=p.VELOCITY_CONTROL, force=0)
p.setJointMotorControl2(robot_id, left_wheel_joint, controlMode=p.VELOCITY_CONTROL, force=0)

# Reset robot to initial state
def reset_robot():
    p.resetBasePositionAndOrientation(robot_id, [0, 0, 0.1], [0, 0, 0, 1])
    p.resetBaseVelocity(robot_id, [0, 0, 0], [0, 0, 0])


def calculate_reward(angle, angular_velocity):

    if abs(angle) < 0.05:  # Near upright
        return 5  # High reward for good balance
    elif abs(angle) < 0.1:  # Slight tilt
        return 1  # Small reward for moderate balance
    elif abs(angle) > 0.5:  # Large tilt
        return -10  # Heavy penalty for falling over
    else:
        return -abs(angle)  # Penalize proportionally to the tilt

# Run the robot using the trained model
def run_robot():
    reset_robot()
    total_reward = 0
    steps = 0

    state_size = 2  # Adjust based on your model
    action_limit = 2.0

    # Initial state
    state = np.reshape([p.getEulerFromQuaternion(p.getBasePositionAndOrientation(robot_id)[1])[1],
                        p.getBaseVelocity(robot_id)[1][1]], [1, state_size])

    for step in range(1000):  # Adjust as needed
        # Predict action using the actor model
        action = actor.predict(state)[0]
        action = np.clip(action, -action_limit, action_limit)

        # Apply action
        p.setJointMotorControl2(robot_id, right_wheel_joint, controlMode=p.TORQUE_CONTROL, force=action[0])
        p.setJointMotorControl2(robot_id, left_wheel_joint, controlMode=p.TORQUE_CONTROL, force=action[0])
        p.stepSimulation()
        time.sleep(1.0 / 240.0)

        # Get next state
        next_state = np.reshape([p.getEulerFromQuaternion(p.getBasePositionAndOrientation(robot_id)[1])[1],
                                 p.getBaseVelocity(robot_id)[1][1]], [1, state_size])

        # Calculate reward
        reward = calculate_reward(next_state[0][0], next_state[0][1])
        total_reward += reward

        state = next_state
        steps += 1

        # Stop if the robot falls over
        if abs(state[0][0]) > 0.5:
            print("Robot fell over!")
            break

    print(f"Run completed. Total reward: {total_reward}, Steps: {steps}")

# Run the robot
run_robot()
